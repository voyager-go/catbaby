const HOST = "http://localhost:8000"
const API = HOST + "/frontend"

const Apis = {
    // 故事角色列表
    getRoleList: API + '/role',
}
export default Apis