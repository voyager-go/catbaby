import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import router from './router/router.js'
import API from './request/http.js'
import App from './App.vue'

Vue.use(ElementUI)

Vue.config.productionTip = false
Vue.prototype.$request = API
// Vue.prototype.$axios = axios

new Vue({
  render: h => h(App),
  router
}).$mount('#app')