import Vue from 'vue'
import Router from 'vue-router'
import RoleList from "../views/role/list.vue"
import RoleDetail from "../views/role/detail.vue"
import MainIndex from "../views/index/index.vue"

const routes = [
    { path: '/role/list', name: 'RoleList', component: RoleList },
    { path: '/role/detail/:id', name: 'RoleDetail', component: RoleDetail },
    { path: '/index', name: 'MainIndex', component: MainIndex },
]

Vue.use(Router)

export default new Router({
    mode: 'history',
    routes
})