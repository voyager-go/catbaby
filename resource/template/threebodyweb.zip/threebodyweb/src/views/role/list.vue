<template>
  <el-row class="voyager-main">
    <el-col :span="12">
      <el-input
          class="voyager-search"
          size="medium"
          placeholder="请输入关键词"
          suffix-icon="el-icon-search"
          @change="handleSearch"
          v-model="keywords">
      </el-input>
      <div  v-if="list.length > 0">
        <el-descriptions class="voyager-desc-container" :column="3" border v-for="item in list" :key="item.id">
          <el-descriptions-item labelClassName="voyager-label" v-for="(v, index) in fields" :key="index">
            <template slot="label">
              <i :class="v.icon"></i>
              {{v.title}}
            </template>
            <span v-if="v.ifRenderHtml" v-html="item[v.field]"></span>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-pear"></i>
              别称
            </template>
            <span v-html="item.nickname"></span>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-s-flag"></i>
              国籍
            </template>
            {{item.nationality}}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-female"></i>
              性别
            </template>
            <el-tag size="small">{{item.gender_text}}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-tableware"></i>
              生存时期
            </template>
            {{item.survival_stage}}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-thumb"></i>
              操作
            </template>
            <a class="voyager-link" :href="'/role/detail/' + item.id">查看</a>
          </el-descriptions-item>
        </el-descriptions>
        <el-pagination
            class="voyager-pagination"
            :page-size="pageInfo.size"
            :pager-count="11"
            @current-change="handleChangePage"
            layout="prev, pager, next"
            :total="pageInfo.total">
        </el-pagination>
      </div>
      <div v-else class="voyager-empty">
        <el-empty description="空不是无，空是一种存在，你得用空这种存在填满自己。"></el-empty>
      </div>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "RoleList",
  data(){
    return {
      fields: [
        {
          title: '姓名',
          field: 'name',
          icon: 'el-icon-user',
          ifRenderHtml: true,
          ifUseTag: false,
        },
        {
          title: '别称',
          icon: 'el-icon-pear',
          field: 'nickname',
          ifRenderHtml: true,
          ifUseTag: false,
        },
        {
          title: '国籍',
          icon: 'el-icon-s-flag',
          field: 'nationality',
          ifRenderHtml: false,
          ifUseTag: false,
        },
        {
          title: '性别',
          icon: 'el-icon-female',
          field: 'nickname',
          ifRenderHtml: false,
          ifUseTag: true,
        },
        {
          title: '生存时期',
          icon: 'el-icon-tableware',
          field: 'survival_stage',
          ifRenderHtml: false,
          ifUseTag: false,
        },
      ],
      keywords: '',
      list: [],
      pageInfo: {
        page: 1,
        size: 3,
        total: 0,
      }
    }
  },
  mounted() {
    this.getRoleList()
  },
  methods: {
    // 获取故事角色列表
    getRoleList(){
      const params = {
        page: this.pageInfo.page,
        size: this.pageInfo.size,
        search: this.keywords,
      }
      this.$request.getRoleList(params).then( (data) => {
        const {list, page, size, total} = data
        this.list = this.lightKeywords(list) || []
        Object.assign(this.pageInfo, {page, size, total})
      })
    },
    // 高亮关键词
    lightKeywords(data){
      if (data !== null && data.length > 0) {
        for (let item of data) {
          if (this.keywords !== '' &&  item.name.indexOf(this.keywords) !== -1){
            item.name = '<span class="voyager-keywords">' + item.name + '</span>'
          }
          if (this.keywords !== '' && item.nickname.indexOf(this.keywords) !== -1){
            item.nickname = '<span class="voyager-keywords">' + item.nickname + '</span>'
          }
        }
      }
      return data
    },
    // 页面更改
    handleChangePage(currentPage){
      this.pageInfo.page = currentPage
      this.getRoleList()
    },
    // 搜索
    handleSearch(keywords){
      this.keywords = keywords
      this.getRoleList()
    },
  }
}
</script>

<style>
  .voyager-main{
    display: flex;
    justify-content: center;
  }
  .voyager-search{
    margin: 30px 0 15px 0;
    width: 40%;
    float: right;
  }
  .voyager-desc-container{
    margin-top: 15px;
  }
  .voyager-pagination{
    margin-top: 15px;
    float: right;
  }
  .voyager-empty{
    margin-top: 150px;
  }
  .voyager-link{
    text-decoration: none;
    color: #409EFF;
    font-weight: 60;
  }
  .voyager-label{
    width: 80px !important;
  }
  /deep/ .voyager-keywords{
    color: #F56C6C;
  }
</style>