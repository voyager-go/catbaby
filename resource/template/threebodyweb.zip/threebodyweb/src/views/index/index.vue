<template>
<div class="voyager-main">
  <div class="block voyager-timeline">
    <el-timeline>
      <el-timeline-item
          v-for="(activity, index) in activities"
          :key="index"
          :icon="activity.icon"
          :type="activity.type"
          :color="activity.color"
          :size="activity.size"
          :timestamp="activity.timestamp">
        <a :href="activity.url" class="voyager-title-router">{{activity.content}}</a>
      </el-timeline-item>
    </el-timeline>
  </div>
</div>
</template>

<script>
export default {
  name: "MainIndex",
  data() {
    return {
      activities: [{
        content: '角色介绍',
        timestamp: '',
        size: 'large',
        type: 'primary',
        icon: 'el-icon-more',
        url: '/role/list'
      }, {
        content: '精彩回顾',
        timestamp: '',
        color: '#0bbd87',
        url: ''
      }, {
        content: '书虫测验',
        timestamp: '',
        size: 'large',
        url: ''
      }, {
        content: '加入组织',
        timestamp: '',
        url: ''
      }]
    };
  }
}
</script>

<style scoped>
  .voyager-main{
    display: flex;
    min-height: 100vh;
    background: url("../../assets/background.jpg") no-repeat fixed center;
    background-size: cover;
  }
  .voyager-timeline{
    position: absolute;
    left: 10%;
    top:15%;
  }
  .voyager-title-router{
    text-decoration: none;
    color: white;
    font-size: 14px;
    font-weight: lighter;
  }
</style>